<?php
echo "<h2>File Version Check</h2>";

$files = [
    '/pages/login/login_process_simple.php',
    '/pages/write/write-simple.php',
    '/login-modern.php'
];

foreach ($files as $file) {
    $fullPath = $_SERVER['DOCUMENT_ROOT'] . $file;
    if (file_exists($fullPath)) {
        echo "<h3>$file</h3>";
        echo "Last modified: " . date('Y-m-d H:i:s', filemtime($fullPath)) . "<br>";
        echo "Size: " . filesize($fullPath) . " bytes<br>";
        
        // Check for redirect logic in login process
        if (strpos($file, 'login_process_simple.php') !== false) {
            $content = file_get_contents($fullPath);
            if (strpos($content, 'strpos($redirect, \'/\') === 0') !== false) {
                echo "<span style='color: green;'>✓ Contains new redirect logic</span><br>";
            } else {
                echo "<span style='color: red;'>✗ Missing new redirect logic</span><br>";
            }
        }
        
        // Check for redirect parameter in write page
        if (strpos($file, 'write-simple.php') !== false) {
            $content = file_get_contents($fullPath);
            if (strpos($content, 'redirect=') !== false) {
                echo "<span style='color: green;'>✓ Contains redirect parameter</span><br>";
            } else {
                echo "<span style='color: red;'>✗ Missing redirect parameter</span><br>";
            }
        }
        
        echo "<br>";
    } else {
        echo "<h3>$file</h3>";
        echo "<span style='color: red;'>File not found!</span><br><br>";
    }
}
?>