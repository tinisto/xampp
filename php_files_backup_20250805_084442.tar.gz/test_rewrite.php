<?php
// Place this file at: /pages/post/test_rewrite.php
echo "<h1>Rewrite Test</h1>";
echo "<p>If you see this when accessing /post/test, the rewrite is working!</p>";
echo "<p>Request URI: " . $_SERVER['REQUEST_URI'] . "</p>";
echo "<p>Script Name: " . $_SERVER['SCRIPT_NAME'] . "</p>";
echo "<p>GET params:</p>";
echo "<pre>" . print_r($_GET, true) . "</pre>";

if (isset($_GET['url_post'])) {
    echo "<h2 style='color:green;'>✓ SUCCESS: Rewrite rule is working!</h2>";
    echo "<p>url_post = " . htmlspecialchars($_GET['url_post']) . "</p>";
} else {
    echo "<h2 style='color:red;'>✗ FAIL: No url_post parameter received</h2>";
}
?>