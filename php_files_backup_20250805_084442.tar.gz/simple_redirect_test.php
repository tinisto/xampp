<?php
session_start();

echo "<h2>Simple Redirect Test</h2>";

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

echo "<h3>Current Page Info:</h3>";
echo "URL: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "User logged in: " . (isset($_SESSION['user_id']) ? 'Yes (ID: ' . $_SESSION['user_id'] . ')' : 'No') . "<br>";

echo "<h3>Test Login with Different Redirect Values:</h3>";
?>

<!-- Test 1: Redirect to this page -->
<form method="post" action="/pages/login/login_process_simple.php" style="border: 1px solid #007bff; padding: 15px; margin: 10px 0;">
    <h4>Test 1: Redirect to current page</h4>
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="redirect" value="<?= $_SERVER['REQUEST_URI'] ?>">
    
    <p>Redirect value: <code><?= htmlspecialchars($_SERVER['REQUEST_URI']) ?></code></p>
    
    <input type="email" name="email" placeholder="Email" style="width: 200px; padding: 5px;"><br><br>
    <input type="password" name="password" placeholder="Password" style="width: 200px; padding: 5px;"><br><br>
    <button type="submit" style="padding: 8px 16px; background: #007bff; color: white; border: none;">Login Test 1</button>
</form>

<!-- Test 2: Redirect to /write -->
<form method="post" action="/pages/login/login_process_simple.php" style="border: 1px solid #28a745; padding: 15px; margin: 10px 0;">
    <h4>Test 2: Redirect to /write</h4>
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="redirect" value="/write">
    
    <p>Redirect value: <code>/write</code></p>
    
    <input type="email" name="email" placeholder="Email" style="width: 200px; padding: 5px;"><br><br>
    <input type="password" name="password" placeholder="Password" style="width: 200px; padding: 5px;"><br><br>
    <button type="submit" style="padding: 8px 16px; background: #28a745; color: white; border: none;">Login Test 2</button>
</form>

<!-- Test 3: Redirect to root -->
<form method="post" action="/pages/login/login_process_simple.php" style="border: 1px solid #ffc107; padding: 15px; margin: 10px 0;">
    <h4>Test 3: Redirect to root</h4>
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="redirect" value="/">
    
    <p>Redirect value: <code>/</code></p>
    
    <input type="email" name="email" placeholder="Email" style="width: 200px; padding: 5px;"><br><br>
    <input type="password" name="password" placeholder="Password" style="width: 200px; padding: 5px;"><br><br>
    <button type="submit" style="padding: 8px 16px; background: #ffc107; color: black; border: none;">Login Test 3</button>
</form>

<?php
echo "<h3>Manual Debug:</h3>";
echo "Try these links manually:<br>";
echo "<a href='/login?redirect=" . urlencode($_SERVER['REQUEST_URI']) . "'>Login with redirect to current page</a><br>";
echo "<a href='/login?redirect=" . urlencode("/write") . "'>Login with redirect to /write</a><br>";
echo "<a href='/login?redirect=" . urlencode("/") . "'>Login with redirect to root</a><br>";
?>