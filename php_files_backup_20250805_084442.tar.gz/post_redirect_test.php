<?php
// Place this at /post_redirect_test.php
// Access it as: /post_redirect_test.php?test=1

echo "<h2>Post Redirect Test</h2>";

if (isset($_GET['test'])) {
    echo "<p>This page is working. Now testing redirect...</p>";
    echo "<p>Clicking the link below should take you to a post page:</p>";
    echo "<a href='/post/ledi-v-pogonah'>Click here to test /post/ledi-v-pogonah</a>";
} else {
    // This part runs when accessed via /post/something
    echo "<h3>Successfully reached post redirect test!</h3>";
    echo "<p>Request URI: " . $_SERVER['REQUEST_URI'] . "</p>";
    echo "<p>Query String: " . $_SERVER['QUERY_STRING'] . "</p>";
    echo "<p>GET parameters:</p>";
    echo "<pre>";
    print_r($_GET);
    echo "</pre>";
}

// Check if we're being called as a post
if (isset($_GET['url_post'])) {
    echo "<h3>Post URL detected: " . htmlspecialchars($_GET['url_post']) . "</h3>";
    echo "<p>This confirms the rewrite rule is working!</p>";
    
    // Now check what happens when we try to load the actual post.php
    $post_file = $_SERVER['DOCUMENT_ROOT'] . '/pages/post/post.php';
    if (file_exists($post_file)) {
        echo "<p>✓ post.php exists at: $post_file</p>";
        echo "<p>The issue might be inside post.php or one of its includes.</p>";
    }
}
?>