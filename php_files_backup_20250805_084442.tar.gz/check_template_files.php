<?php
echo "<h2>Checking Template Files on Server</h2>";

$files_to_check = [
    '/common-components/template-engine-ultimate.php',
    '/common-components/template-engine-modern.php',
    '/common-components/header.php',
    '/common-components/footer-unified.php',
    '/pages/post/post-content.php'
];

echo "<table border='1'>";
echo "<tr><th>File</th><th>Status</th></tr>";

foreach ($files_to_check as $file) {
    $full_path = $_SERVER['DOCUMENT_ROOT'] . $file;
    $exists = file_exists($full_path);
    
    echo "<tr>";
    echo "<td>$file</td>";
    echo "<td>" . ($exists ? "✓ EXISTS" : "<span style='color:red'>✗ MISSING</span>") . "</td>";
    echo "</tr>";
}

echo "</table>";

// Also check if there's an error in post-content.php
$post_content = $_SERVER['DOCUMENT_ROOT'] . '/pages/post/post-content.php';
if (file_exists($post_content)) {
    echo "<h3>Checking post-content.php for issues:</h3>";
    
    // Check first few lines
    $lines = file($post_content, FILE_IGNORE_NEW_LINES);
    echo "<pre>";
    echo "First 10 lines of post-content.php:\n";
    for ($i = 0; $i < min(10, count($lines)); $i++) {
        echo ($i + 1) . ": " . htmlspecialchars($lines[$i]) . "\n";
    }
    echo "</pre>";
}
?>