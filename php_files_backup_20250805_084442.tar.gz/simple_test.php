<?php
echo "Simple PHP test - " . date('Y-m-d H:i:s');
?>