<?php
// Simple script to check existing posts without complex environment setup
// This assumes standard XAMPP MySQL setup

echo "<h2>Checking Existing Posts</h2>";

// Try to connect to MySQL using credentials from .env
$host = 'localhost';
$username = 'root';
$password = 'root';

// First, let's see what databases exist
$connection = new mysqli($host, $username, $password);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

echo "<h3>Available Databases:</h3>";
$result = $connection->query("SHOW DATABASES");
while ($row = $result->fetch_assoc()) {
    echo "- " . $row['Database'] . "<br>";
}

// Now let's try to find a database with posts table  
$databases = ['11klassniki_claude', '11klassniki', '11klassniki_new', 'test'];

foreach ($databases as $dbname) {
    echo "<h3>Checking database: $dbname</h3>";
    
    if ($connection->select_db($dbname)) {
        echo "✓ Connected to $dbname<br>";
        
        // Check if posts table exists
        $result = $connection->query("SHOW TABLES LIKE 'posts'");
        if ($result && $result->num_rows > 0) {
            echo "✓ Posts table found<br>";
            
            // Get sample posts
            $result = $connection->query("SELECT id, post_title, url_slug FROM posts WHERE is_active = 1 ORDER BY created_at DESC LIMIT 10");
            if ($result && $result->num_rows > 0) {
                echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
                echo "<tr><th>ID</th><th>Title</th><th>URL Slug</th><th>Link</th></tr>";
                
                while ($row = $result->fetch_assoc()) {
                    $url_slug = $row['url_slug'];
                    $link = $url_slug ? "/post/{$url_slug}" : "NO URL";
                    
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>" . htmlspecialchars($row['post_title']) . "</td>";
                    echo "<td>" . ($url_slug ? htmlspecialchars($url_slug) : "<span style='color:red;'>EMPTY</span>") . "</td>";
                    echo "<td>" . ($url_slug ? "<a href='{$link}' target='_blank'>View Post</a>" : "NO LINK") . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
                break; // Found working database, stop searching
            } else {
                echo "No active posts found<br>";
            }
        } else {
            echo "No posts table found<br>";
        }
    } else {
        echo "Could not connect to $dbname<br>";
    }
}

$connection->close();
?>