<?php
// Temporary redirect to the working standalone version
header("Location: /forgot-password-standalone.php");
exit;