<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';

echo "<h2>Checking Which Posts Lead to Error</h2>";

// List of post URLs from the main page
$test_urls = [
    'ledi-v-pogonah',
    'kogda-ege-ostalis-pozadi',
    'ya-reshila-stat-vrachom',
    'prinosit-dobro-lyudyam',
    'proektirovanie-zdaniy',
    'mechta-s-detstva-byit-doktorom',
    'prodoljaya-semeynyie-traditsii',
    'uvlechenie-jurnalistikoy',
    'spetsialist-po-kompyuteram',
    'tantsyi-i-angliyskiy-yazyik',
    'byit-studentkoy-vshe',
    'novoe-mesto-uchebyi',
    'mechta-obyezdit-ves-mir',
    'hochu-rabotat-stroitelem',
    'sereznaya-i-nujnaya-professiya',
    'lyubimyiy-angliyskiy-yazyik',
    'otlichnyiy-dizayner-interera',
    'byit-sovremennyim-chelovekom',
    'himiya-dlya-buduschego-vracha',
    'lyublyu-ustraivat-prazdniki'
];

echo "<h3>Testing Post URLs:</h3>";
echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>URL</th><th>Database Status</th><th>Test Link</th></tr>";

$not_found = [];

foreach ($test_urls as $url) {
    $query = "SELECT id_post, title_post FROM posts WHERE url_slug = ?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "s", $url);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $exists = false;
    $title = '';
    if ($row = mysqli_fetch_assoc($result)) {
        $exists = true;
        $title = $row['title_post'];
    }
    
    echo "<tr>";
    echo "<td>" . htmlspecialchars($url) . "</td>";
    echo "<td style='color:" . ($exists ? "green" : "red") . "'>";
    if ($exists) {
        echo "✓ Found: " . htmlspecialchars($title);
    } else {
        echo "✗ NOT FOUND";
        $not_found[] = $url;
    }
    echo "</td>";
    echo "<td><a href='/post/" . $url . "' target='_blank'>Test</a></td>";
    echo "</tr>";
    
    mysqli_stmt_close($stmt);
}

echo "</table>";

if (count($not_found) > 0) {
    echo "<h3 style='color:red;'>Posts Not Found in Database:</h3>";
    echo "<ul>";
    foreach ($not_found as $url) {
        echo "<li>" . htmlspecialchars($url) . "</li>";
    }
    echo "</ul>";
    echo "<p>These URLs will redirect to /404 (which might appear as /error)</p>";
}

// Also check if there's a 404.php file
$file_404 = $_SERVER['DOCUMENT_ROOT'] . '/pages/404/404.php';
if (file_exists($file_404)) {
    echo "<h3>404 Page Status:</h3>";
    echo "<p>✓ 404.php exists at: $file_404</p>";
    
    // Check if 404.php redirects to /error
    $content = file_get_contents($file_404);
    if (stripos($content, 'Location: /error') !== false) {
        echo "<p style='color:red;'>⚠️ 404.php redirects to /error</p>";
    }
} else {
    echo "<p style='color:red;'>✗ 404.php NOT FOUND</p>";
}

mysqli_close($connection);
?>