<?php
echo "<h2>Checking .htaccess Configuration</h2>";

$htaccess_path = $_SERVER['DOCUMENT_ROOT'] . '/.htaccess';

if (file_exists($htaccess_path)) {
    echo "✓ .htaccess file exists<br><br>";
    
    $content = file_get_contents($htaccess_path);
    
    // Check for post rewrite rule
    if (strpos($content, 'RewriteRule ^post/([^/]+)/?$ pages/post/post.php?url_post=$1') !== false) {
        echo "✓ Post rewrite rule found<br>";
        
        // Show the rule
        preg_match('/RewriteRule \^post\/.*$/m', $content, $matches);
        if ($matches) {
            echo "Rule: <code>" . htmlspecialchars($matches[0]) . "</code><br>";
        }
    } else {
        echo "✗ Post rewrite rule NOT FOUND<br>";
    }
    
    // Check if RewriteEngine is on
    if (strpos($content, 'RewriteEngine On') !== false) {
        echo "✓ RewriteEngine is On<br>";
    } else {
        echo "✗ RewriteEngine is NOT On<br>";
    }
    
    // Check for error handling
    if (strpos($content, 'ErrorDocument 404') !== false) {
        echo "✓ 404 ErrorDocument configured<br>";
    }
    
    // Show relevant lines
    echo "<br><h3>Post-related lines in .htaccess:</h3>";
    echo "<pre>";
    $lines = explode("\n", $content);
    foreach ($lines as $num => $line) {
        if (stripos($line, 'post') !== false || stripos($line, 'error') !== false) {
            echo ($num + 1) . ": " . htmlspecialchars($line) . "\n";
        }
    }
    echo "</pre>";
    
} else {
    echo "✗ .htaccess file NOT FOUND<br>";
}

// Check mod_rewrite
echo "<h3>Server Configuration:</h3>";
if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    if (in_array('mod_rewrite', $modules)) {
        echo "✓ mod_rewrite is enabled<br>";
    } else {
        echo "✗ mod_rewrite is NOT enabled<br>";
    }
} else {
    echo "Cannot check Apache modules (apache_get_modules not available)<br>";
}

// Test direct access
echo "<h3>Testing Direct Access:</h3>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Request URI when accessing /post/test: " . $_SERVER['REQUEST_URI'] . "<br>";
?>