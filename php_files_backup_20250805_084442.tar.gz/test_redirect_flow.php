<?php
echo "<h2>Test Redirect Flow</h2>";

echo "<h3>1. Simulate Write Page Login Link</h3>";
$currentUri = "/write";
$loginUrl = "/login?redirect=" . urlencode($currentUri);
echo "Write page would create this login URL: <br>";
echo "<a href='$loginUrl' target='_blank'>$loginUrl</a><br><br>";

echo "<h3>2. Check Login Form</h3>";
if (isset($_GET['redirect'])) {
    echo "Redirect parameter received: " . htmlspecialchars($_GET['redirect']) . "<br>";
    echo "Login form should include this as hidden field<br><br>";
} else {
    echo "No redirect parameter in URL<br><br>";
}

echo "<h3>3. Test Login Process with Redirect</h3>";
echo "Login form with redirect parameter:<br>";
?>

<form method="post" action="/debug_login_process_with_logging.php" style="border: 1px solid #ccc; padding: 20px; margin: 20px 0; background: #ffffcc;">
    <h4>Test Login (use your real credentials)</h4>
    
    <input type="hidden" name="csrf_token" value="test_token">
    <input type="hidden" name="redirect" value="/write">
    
    <label>Email:</label><br>
    <input type="email" name="email" required style="width: 300px; padding: 5px;"><br><br>
    
    <label>Password:</label><br>  
    <input type="password" name="password" required style="width: 300px; padding: 5px;"><br><br>
    
    <button type="submit">Test Login with Redirect to /write</button>
    
    <p><small>This will attempt to log you in and redirect to /write</small></p>
</form>

<?php
echo "<h3>4. Debug Info</h3>";
echo "Current page: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "Server host: " . $_SERVER['HTTP_HOST'] . "<br>";

if (isset($_GET['redirect'])) {
    $testRedirect = $_GET['redirect'];
    echo "<br>Testing redirect validation for: '$testRedirect'<br>";
    echo "Starts with /: " . (strpos($testRedirect, '/') === 0 ? 'yes' : 'no') . "<br>";
    echo "Starts with //: " . (strpos($testRedirect, '//') === 0 ? 'yes' : 'no') . "<br>";
    echo "Would pass security check: " . ((strpos($testRedirect, '/') === 0 && strpos($testRedirect, '//') !== 0) ? 'yes' : 'no') . "<br>";
}
?>