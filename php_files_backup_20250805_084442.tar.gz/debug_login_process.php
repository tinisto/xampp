<?php
session_start();

// Debug version of login process to see what's happening
echo "<h2>Debug Login Process</h2>";

if ($_POST) {
    echo "<h3>POST Data:</h3>";
    echo "Email: " . ($_POST['email'] ?? 'not set') . "<br>";
    echo "Password: " . (isset($_POST['password']) ? '[hidden]' : 'not set') . "<br>";
    echo "Redirect: " . ($_POST['redirect'] ?? 'not set') . "<br>";
    echo "CSRF Token: " . ($_POST['csrf_token'] ?? 'not set') . "<br>";
    
    $redirect = $_POST['redirect'] ?? null;
    
    echo "<h3>Redirect Logic:</h3>";
    echo "Redirect value: '$redirect'<br>";
    echo "Is redirect set: " . ($redirect ? 'yes' : 'no') . "<br>";
    
    if ($redirect) {
        echo "Starts with /: " . (strpos($redirect, '/') === 0 ? 'yes' : 'no') . "<br>";
        echo "Starts with //: " . (strpos($redirect, '//') === 0 ? 'yes' : 'no') . "<br>";
        echo "Security check passes: " . ((strpos($redirect, '/') === 0 && strpos($redirect, '//') !== 0) ? 'yes' : 'no') . "<br>";
        
        if (strpos($redirect, '/') === 0 && strpos($redirect, '//') !== 0) {
            echo "<strong>Would redirect to: $redirect</strong><br>";
        } else {
            echo "<strong>Security check failed, would use default redirect</strong><br>";
        }
    } else {
        echo "<strong>No redirect parameter, would use default redirect</strong><br>";
    }
} else {
    echo "No POST data received<br>";
}

echo "<h3>Test Login Form:</h3>";
?>
<form method="post">
    <input type="hidden" name="csrf_token" value="test">
    <input type="hidden" name="redirect" value="/write">
    <input type="email" name="email" placeholder="Email" value="test@example.com"><br><br>
    <input type="password" name="password" placeholder="Password" value="test"><br><br>
    <button type="submit">Test Debug</button>
</form>