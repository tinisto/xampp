<?php
require_once __DIR__ . '/database/db_connections.php';

echo "<h2>Checking Posts URLs</h2>";

// Get some posts from category 1
$query = "SELECT id_post, title_post, url_post FROM posts WHERE category = 1 ORDER BY date_post DESC LIMIT 10";
$result = mysqli_query($connection, $query);

if (!$result) {
    echo "Query error: " . mysqli_error($connection);
    exit;
}

echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>ID</th><th>Title</th><th>URL Post</th><th>Link</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $url_post = $row['url_post'];
    $link = $url_post ? "/post/{$url_post}" : "NO URL";
    
    echo "<tr>";
    echo "<td>{$row['id_post']}</td>";
    echo "<td>" . htmlspecialchars($row['title_post']) . "</td>";
    echo "<td>" . ($url_post ? htmlspecialchars($url_post) : "<span style='color:red;'>EMPTY</span>") . "</td>";
    echo "<td>" . ($url_post ? "<a href='{$link}'>View</a>" : "NO LINK") . "</td>";
    echo "</tr>";
}

echo "</table>";

// Check if url_post column exists
echo "<h3>Table Structure:</h3>";
$query = "SHOW COLUMNS FROM posts LIKE 'url_post'";
$result = mysqli_query($connection, $query);
if (mysqli_num_rows($result) > 0) {
    echo "✓ url_post column exists<br>";
    $col = mysqli_fetch_assoc($result);
    echo "Type: " . $col['Type'] . "<br>";
    echo "Null: " . $col['Null'] . "<br>";
} else {
    echo "<span style='color:red;'>✗ url_post column NOT FOUND</span><br>";
}

mysqli_close($connection);
?>