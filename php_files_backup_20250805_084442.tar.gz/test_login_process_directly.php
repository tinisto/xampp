<?php
echo "<h2>Test Login Process Logic Directly</h2>";

// Simulate the exact logic from login_process_simple.php
$redirect = "/write";

echo "<h3>Testing redirect logic with value: '$redirect'</h3>";

echo "Redirect is set: " . ($redirect ? 'yes' : 'no') . "<br>";

if ($redirect) {
    echo "Testing security checks:<br>";
    echo "- strpos(\$redirect, '/') === 0: " . (strpos($redirect, '/') === 0 ? 'TRUE' : 'FALSE') . "<br>";
    echo "- strpos(\$redirect, '//') !== 0: " . (strpos($redirect, '//') !== 0 ? 'TRUE' : 'FALSE') . "<br>";
    
    if (strpos($redirect, '/') === 0 && strpos($redirect, '//') !== 0) {
        echo "<strong style='color: green;'>✅ Security check PASSED - would redirect to: $redirect</strong><br>";
    } else {
        echo "<strong style='color: red;'>❌ Security check FAILED</strong><br>";
    }
} else {
    echo "<strong>No redirect parameter</strong><br>";
}

echo "<h3>Test with different values:</h3>";
$testValues = ["/write", "/", "/test", "write", "//evil.com", ""];

foreach ($testValues as $testRedirect) {
    echo "<div style='border: 1px solid #ddd; padding: 10px; margin: 5px 0;'>";
    echo "<strong>Testing: '" . htmlspecialchars($testRedirect) . "'</strong><br>";
    
    if ($testRedirect) {
        $check1 = strpos($testRedirect, '/') === 0;
        $check2 = strpos($testRedirect, '//') !== 0;
        $passes = $check1 && $check2;
        
        echo "Starts with /: " . ($check1 ? 'YES' : 'NO') . "<br>";
        echo "Not starts with //: " . ($check2 ? 'YES' : 'NO') . "<br>";
        echo "Result: " . ($passes ? '<span style="color: green;">PASS</span>' : '<span style="color: red;">FAIL</span>') . "<br>";
    } else {
        echo "Empty value: <span style='color: red;'>FAIL</span><br>";
    }
    echo "</div>";
}

echo "<h3>Check actual server file:</h3>";
$loginFile = $_SERVER['DOCUMENT_ROOT'] . '/pages/login/login_process_simple.php';
$content = file_get_contents($loginFile);

// Check if the redirect logic exists
if (strpos($content, 'strpos($redirect, \'/\') === 0') !== false) {
    echo "✅ Server file contains correct redirect logic<br>";
} else {
    echo "❌ Server file missing redirect logic<br>";
}

// Check if there are any other redirect statements that might interfere
$redirectMatches = [];
preg_match_all('/header\s*\(\s*[\'"]Location:\s*([^\'"]+)[\'"]/', $content, $redirectMatches);

echo "<h4>All redirect statements in login process:</h4>";
if (!empty($redirectMatches[1])) {
    foreach ($redirectMatches[1] as $i => $redirectUrl) {
        echo ($i + 1) . ". header('Location: $redirectUrl')<br>";
    }
} else {
    echo "No redirect statements found<br>";
}
?>