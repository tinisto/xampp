<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';

echo "<h2>Checking All Posts on Main Page</h2>";

// Check posts from category 1 (11-классники)
echo "<h3>Category 1 Posts (11-классники):</h3>";
$query1 = "SELECT id_post, title_post, url_post FROM posts WHERE category = 1 ORDER BY date_post DESC LIMIT 10";
$result1 = mysqli_query($connection, $query1);

echo "<table border='1'>";
echo "<tr><th>ID</th><th>Title</th><th>URL</th><th>Test</th></tr>";
while ($row = mysqli_fetch_assoc($result1)) {
    echo "<tr>";
    echo "<td>{$row['id_post']}</td>";
    echo "<td>" . htmlspecialchars($row['title_post']) . "</td>";
    echo "<td>" . htmlspecialchars($row['url_post']) . "</td>";
    echo "<td><a href='/post/{$row['url_post']}' target='_blank'>Test</a></td>";
    echo "</tr>";
}
echo "</table>";

// Check posts from category 2 (Абитуриенты)
echo "<h3>Category 2 Posts (Абитуриенты):</h3>";
$query2 = "SELECT id_post, title_post, url_post FROM posts WHERE category = 2 ORDER BY date_post DESC LIMIT 10";
$result2 = mysqli_query($connection, $query2);

echo "<table border='1'>";
echo "<tr><th>ID</th><th>Title</th><th>URL</th><th>Test</th></tr>";
while ($row = mysqli_fetch_assoc($result2)) {
    echo "<tr>";
    echo "<td>{$row['id_post']}</td>";
    echo "<td>" . htmlspecialchars($row['title_post']) . "</td>";
    echo "<td>" . htmlspecialchars($row['url_post']) . "</td>";
    echo "<td><a href='/post/{$row['url_post']}' target='_blank'>Test</a></td>";
    echo "</tr>";
}
echo "</table>";

// Check the actual queries used in index_content_modern.php
echo "<h3>Checking Main Page Queries:</h3>";

// First section - Category 1
$query11 = "SELECT * FROM posts WHERE category = 1 ORDER BY date_post DESC LIMIT 6";
$result11 = mysqli_query($connection, $query11);
echo "<p>Category 1 query returned: " . mysqli_num_rows($result11) . " rows</p>";

// Second section - Category 2
$queryAbiturient = "SELECT * FROM posts WHERE category = 2 ORDER BY date_post DESC LIMIT 4";
$resultAbiturient = mysqli_query($connection, $queryAbiturient);
echo "<p>Category 2 query returned: " . mysqli_num_rows($resultAbiturient) . " rows</p>";

// Check if there are any posts with empty URLs
echo "<h3>Posts with Empty URLs:</h3>";
$emptyQuery = "SELECT id_post, title_post, url_post FROM posts WHERE (url_post IS NULL OR url_post = '') AND category IN (1, 2)";
$emptyResult = mysqli_query($connection, $emptyQuery);

if (mysqli_num_rows($emptyResult) > 0) {
    echo "<p style='color:red;'>Found posts with empty URLs:</p>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Title</th><th>URL</th></tr>";
    while ($row = mysqli_fetch_assoc($emptyResult)) {
        echo "<tr>";
        echo "<td>{$row['id_post']}</td>";
        echo "<td>" . htmlspecialchars($row['title_post']) . "</td>";
        echo "<td><span style='color:red;'>EMPTY</span></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:green;'>No posts with empty URLs found.</p>";
}

mysqli_close($connection);
?>