<?php
// Enable error reporting and logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

echo "<h2>Debug Write Page with Full Error Logging</h2>";

// Start output buffering to catch any output
ob_start();

// Capture all errors
$errors = [];
set_error_handler(function($severity, $message, $file, $line) use (&$errors) {
    $errors[] = [
        'severity' => $severity,
        'message' => $message,
        'file' => $file,
        'line' => $line,
        'type' => 'error'
    ];
    return true;
});

// Capture fatal errors
register_shutdown_function(function() use (&$errors) {
    $lastError = error_get_last();
    if ($lastError && in_array($lastError['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        $errors[] = [
            'severity' => $lastError['type'],
            'message' => $lastError['message'],
            'file' => $lastError['file'],
            'line' => $lastError['line'],
            'type' => 'fatal'
        ];
    }
});

echo "<h3>Attempting to execute write page...</h3>";

try {
    // Simulate the exact same environment as the real request
    $_SERVER['REQUEST_URI'] = '/write';
    
    // Include the write page
    include $_SERVER['DOCUMENT_ROOT'] . '/pages/write/write-simple.php';
    
    echo "<br><h3>✓ Write page executed successfully!</h3>";
    
} catch (Exception $e) {
    $errors[] = [
        'type' => 'exception',
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ];
} catch (Error $e) {
    $errors[] = [
        'type' => 'fatal_error',
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ];
}

// Get any output
$pageOutput = ob_get_clean();

// Restore error handler
restore_error_handler();

// Show results
if (!empty($errors)) {
    echo "<h3 style='color: red;'>❌ Errors Found:</h3>";
    foreach ($errors as $error) {
        echo "<div style='background: #ffeeee; padding: 10px; margin: 10px 0; border: 1px solid #ffcccc;'>";
        echo "<strong>Type:</strong> " . $error['type'] . "<br>";
        echo "<strong>Message:</strong> " . htmlspecialchars($error['message']) . "<br>";
        if (isset($error['file'])) {
            echo "<strong>File:</strong> " . htmlspecialchars($error['file']) . "<br>";
            echo "<strong>Line:</strong> " . $error['line'] . "<br>";
        }
        if (isset($error['trace'])) {
            echo "<strong>Trace:</strong><br><pre>" . htmlspecialchars($error['trace']) . "</pre>";
        }
        echo "</div>";
    }
} else {
    echo "<h3 style='color: green;'>✅ No Errors Found</h3>";
}

echo "<h3>Page Output Preview:</h3>";
echo "<div style='background: #f5f5f5; padding: 10px; max-height: 300px; overflow-y: auto; border: 1px solid #ddd;'>";
echo htmlspecialchars(substr($pageOutput, 0, 2000));
if (strlen($pageOutput) > 2000) {
    echo "<br><em>... (output truncated)</em>";
}
echo "</div>";

echo "<h3>Direct Test Links:</h3>";
echo "<a href='/write' target='_blank'>Test /write</a> (might redirect to error)<br>";
echo "<a href='/pages/write/write-simple.php' target='_blank'>Test direct file access</a><br>";
?>