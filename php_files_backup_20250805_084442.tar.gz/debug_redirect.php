<?php
echo "<h2>Debug Redirect Logic</h2>";

echo "<h3>Current URL:</h3>";
echo $_SERVER['REQUEST_URI'] . "<br>";

echo "<h3>Login link would be:</h3>";
$loginUrl = "/login?redirect=" . urlencode($_SERVER['REQUEST_URI']);
echo '<a href="' . $loginUrl . '">' . $loginUrl . '</a><br>';

echo "<h3>Test redirect parsing:</h3>";
$testRedirect = "/write";
$parsed = parse_url($testRedirect);
echo "Original: $testRedirect<br>";
echo "Parsed: ";
var_dump($parsed);
echo "<br>";

echo "Host check: ";
echo "empty host: " . (empty($parsed['host']) ? 'true' : 'false') . "<br>";
echo "Server host: " . $_SERVER['HTTP_HOST'] . "<br>";

echo "<h3>Filter validation:</h3>";
$isValid = filter_var($testRedirect, FILTER_VALIDATE_URL, FILTER_FLAG_PATH_REQUIRED);
echo "Is valid URL: " . ($isValid !== false ? 'true' : 'false') . "<br>";

echo "<h3>Alternative validation:</h3>";
$isRelativePath = (strpos($testRedirect, '/') === 0 && strpos($testRedirect, '//') !== 0);
echo "Is relative path: " . ($isRelativePath ? 'true' : 'false') . "<br>";
?>