<?php
// Simple test file to verify uploads are working
echo "This is the NEW vanilla CSS version uploaded at: " . date('Y-m-d H:i:s');
echo "\n\nFile size: " . filesize(__FILE__) . " bytes";
echo "\n\nIf you see this, the upload worked!";
?>