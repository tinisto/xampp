<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Full Post Page Test</h2>";

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get database connection
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';

// Test with a known post
$url_post = 'ledi-v-pogonah';

echo "<h3>Testing post: $url_post</h3>";

// Fetch post data
$query = "SELECT * FROM posts WHERE url_slug = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $url_post);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    echo "✓ Post found in database<br>";
    echo "Title: " . htmlspecialchars($row['title_post']) . "<br>";
    echo "ID: " . $row['id_post'] . "<br>";
    echo "Category: " . $row['category'] . "<br>";
    
    $pageTitle = $row['title_post'];
    $postData = $row;
    $metaD = $row['meta_d_post'] ?? '';
    $metaK = $row['meta_k_post'] ?? '';
    
    // Test template includes
    echo "<h3>Testing template includes:</h3>";
    
    $templateFile = $_SERVER['DOCUMENT_ROOT'] . '/common-components/template-engine-ultimate.php';
    if (file_exists($templateFile)) {
        echo "✓ template-engine-ultimate.php exists<br>";
        
        // Check if renderTemplate function exists
        include_once $templateFile;
        if (function_exists('renderTemplate')) {
            echo "✓ renderTemplate function exists<br>";
        } else {
            echo "✗ renderTemplate function NOT FOUND<br>";
        }
    }
    
    // Check post-content.php
    $contentFile = $_SERVER['DOCUMENT_ROOT'] . '/pages/post/post-content.php';
    if (file_exists($contentFile)) {
        echo "✓ post-content.php exists<br>";
    }
    
    // Check what happens when we try to render
    echo "<h3>Attempting to render post:</h3>";
    echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>";
    
    try {
        // Set up the data for post-content.php
        $rowPost = $postData;
        
        // Try to include post-content directly
        ob_start();
        include $contentFile;
        $content = ob_get_clean();
        
        if (strlen($content) > 0) {
            echo "✓ Content rendered successfully (" . strlen($content) . " bytes)<br>";
            echo "<details><summary>View content snippet</summary><pre>" . htmlspecialchars(substr($content, 0, 500)) . "...</pre></details>";
        } else {
            echo "✗ No content rendered<br>";
        }
        
    } catch (Exception $e) {
        echo "ERROR: " . $e->getMessage() . "<br>";
    }
    
    echo "</div>";
    
} else {
    echo "✗ Post NOT FOUND in database<br>";
}

mysqli_stmt_close($stmt);

// Show direct links
echo "<h3>Test Links:</h3>";
echo "<a href='/post/ledi-v-pogonah' target='_blank'>Test Post Link (new tab)</a><br>";
echo "<a href='/pages/post/post.php?url_post=ledi-v-pogonah' target='_blank'>Direct PHP Link (new tab)</a><br>";

// Check error page
echo "<h3>Checking error page:</h3>";
$errorPage = $_SERVER['DOCUMENT_ROOT'] . '/pages/error/error.php';
if (file_exists($errorPage)) {
    echo "✓ /pages/error/error.php exists<br>";
} else {
    echo "✗ /pages/error/error.php NOT FOUND<br>";
}
?>