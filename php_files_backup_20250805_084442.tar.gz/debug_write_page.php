<?php
echo "<h2>Debug Write Page Error</h2>";

echo "<h3>Test Write Page Components</h3>";

// Test 1: Check if write-simple.php exists
$writeFile = $_SERVER['DOCUMENT_ROOT'] . '/pages/write/write-simple.php';
if (file_exists($writeFile)) {
    echo "✓ write-simple.php exists<br>";
} else {
    echo "✗ write-simple.php not found<br>";
}

// Test 2: Check .htaccess rule
echo "<br><h3>Check .htaccess rule for /write</h3>";
$htaccess = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/.htaccess');
if (strpos($htaccess, '/write') !== false) {
    echo "✓ Found /write in .htaccess<br>";
    
    // Extract the write rule
    $lines = explode("\n", $htaccess);
    foreach ($lines as $line) {
        if (strpos($line, '/write') !== false && strpos($line, 'RewriteRule') !== false) {
            echo "<code>" . htmlspecialchars(trim($line)) . "</code><br>";
        }
    }
} else {
    echo "✗ No /write rule found in .htaccess<br>";
}

// Test 3: Try to include the write page and catch errors
echo "<br><h3>Test Write Page Execution</h3>";
ob_start();
$error = null;

try {
    // Suppress any output and capture errors
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    
    // Try to include the write page
    $oldErrorHandler = set_error_handler(function($severity, $message, $file, $line) use (&$error) {
        $error = "Error: $message in $file on line $line";
        return true;
    });
    
    include $writeFile;
    
    restore_error_handler();
    
} catch (Exception $e) {
    $error = "Exception: " . $e->getMessage();
} catch (Error $e) {
    $error = "Fatal Error: " . $e->getMessage();
}

$output = ob_get_clean();

if ($error) {
    echo "✗ Write page has error: " . htmlspecialchars($error) . "<br>";
} else {
    echo "✓ Write page executed without fatal errors<br>";
}

// Test 4: Check required files
echo "<br><h3>Check Required Files</h3>";
$requiredFiles = [
    '/common-components/header.php',
    '/common-components/footer-unified.php',
    '/css/unified-styles.css'
];

foreach ($requiredFiles as $file) {
    $fullPath = $_SERVER['DOCUMENT_ROOT'] . $file;
    if (file_exists($fullPath)) {
        echo "✓ $file exists<br>";
    } else {
        echo "✗ $file missing<br>";
    }
}

echo "<br><h3>Direct Access Test</h3>";
echo "<a href='/pages/write/write-simple.php' target='_blank'>Test direct access to write-simple.php</a><br>";
?>