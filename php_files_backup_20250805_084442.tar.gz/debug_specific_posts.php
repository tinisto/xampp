<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';

echo "<h2>Debug Specific Posts</h2>";

// List of posts that are failing
$test_posts = [
    'ledi-v-pogonah',
    'kogda-ege-ostalis-pozadi', 
    'ya-reshila-stat-vrachom',
    'mechta-s-detstva-byit-doktorom',
    'prodoljaya-semeynyie-traditsii',
    'uvlechenie-jurnalistikoy',
    'spetsialist-po-kompyuteram',
    'tantsyi-i-angliyskiy-yazyik'
];

echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>URL</th><th>DB Check</th><th>Direct PHP</th><th>Rewrite Test</th><th>Special Chars</th></tr>";

foreach ($test_posts as $url) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($url) . "</td>";
    
    // Check database
    $query = "SELECT id_post, title_post, text_post FROM posts WHERE url_slug = ?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "s", $url);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        echo "<td style='color:green;'>✓ Found<br>";
        echo "ID: " . $row['id_post'] . "<br>";
        echo "Title: " . htmlspecialchars(substr($row['title_post'], 0, 30)) . "...</td>";
        
        // Check for any special characters or issues in the post data
        $has_special = false;
        if (preg_match('/[^\x00-\x7F]/', $row['text_post'])) {
            $has_special = true;
        }
    } else {
        echo "<td style='color:red;'>✗ Not Found</td>";
    }
    
    // Direct PHP test
    echo "<td><a href='/pages/post/post.php?url_post=" . $url . "' target='_blank'>Test Direct</a></td>";
    
    // Rewrite test
    echo "<td><a href='/post/" . $url . "' target='_blank'>Test Rewrite</a></td>";
    
    // Special chars check
    echo "<td>";
    if (preg_match('/[^a-z0-9\-]/', $url)) {
        echo "<span style='color:red;'>Has special chars!</span>";
    } else {
        echo "<span style='color:green;'>Clean</span>";
    }
    echo "</td>";
    
    echo "</tr>";
    mysqli_stmt_close($stmt);
}

echo "</table>";

// Check for any database encoding issues
echo "<h3>Database Encoding Check:</h3>";
$encoding_query = "SHOW VARIABLES LIKE 'character_set%'";
$encoding_result = mysqli_query($connection, $encoding_query);
echo "<pre>";
while ($row = mysqli_fetch_assoc($encoding_result)) {
    echo $row['Variable_name'] . ": " . $row['Value'] . "\n";
}
echo "</pre>";

// Test a specific failing post in detail
echo "<h3>Detailed Test - ledi-v-pogonah:</h3>";
$test_url = 'ledi-v-pogonah';
$query = "SELECT * FROM posts WHERE url_slug = ? LIMIT 1";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $test_url);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    echo "<pre>";
    echo "ID: " . $row['id_post'] . "\n";
    echo "URL: '" . $row['url_post'] . "' (length: " . strlen($row['url_post']) . ")\n";
    echo "URL hex: " . bin2hex($row['url_post']) . "\n";
    echo "Title: " . $row['title_post'] . "\n";
    echo "Category: " . $row['category'] . "\n";
    echo "Text length: " . strlen($row['text_post']) . "\n";
    echo "</pre>";
    
    // Check for hidden characters
    if ($row['url_post'] !== trim($row['url_post'])) {
        echo "<p style='color:red;'>WARNING: URL has leading/trailing spaces!</p>";
    }
}

mysqli_close($connection);
?>