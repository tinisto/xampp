<?php
session_start();

echo "<h2>Debug Exact Execution</h2>";

// Simulate the login process with logging
if ($_POST) {
    $redirect = $_POST['redirect'] ?? null;
    
    echo "<h3>POST Data Received:</h3>";
    echo "Redirect parameter: '" . ($redirect ?? 'null') . "'<br>";
    echo "Type: " . gettype($redirect) . "<br>";
    echo "Length: " . strlen($redirect ?? '') . "<br>";
    echo "Raw bytes: " . bin2hex($redirect ?? '') . "<br>";
    
    echo "<h3>Executing redirect logic:</h3>";
    
    if ($redirect) {
        echo "✓ Redirect is truthy<br>";
        
        $check1 = strpos($redirect, '/') === 0;
        $check2 = strpos($redirect, '//') !== 0;
        
        echo "Check 1 (starts with /): " . ($check1 ? 'PASS' : 'FAIL') . "<br>";
        echo "Check 2 (not starts with //): " . ($check2 ? 'PASS' : 'FAIL') . "<br>";
        
        if ($check1 && $check2) {
            echo "<strong style='color: green;'>Security check PASSED</strong><br>";
            echo "Would execute: header('Location: " . $redirect . "')<br>";
            echo "Would then execute: exit()<br>";
            
            // Test the actual header construction
            $headerString = 'Location: ' . $redirect;
            echo "Full header string: '$headerString'<br>";
            echo "Header string length: " . strlen($headerString) . "<br>";
            
            // Don't actually redirect, just show what would happen
            echo "<div style='background: #d4edda; padding: 15px; margin: 15px 0; border-radius: 5px;'>";
            echo "<h4>✅ REDIRECT WOULD WORK!</h4>";
            echo "<p>The redirect logic is correct and would send you to: <strong>$redirect</strong></p>";
            echo "<p><a href='$redirect'>Click here to go to $redirect manually</a></p>";
            echo "</div>";
            
        } else {
            echo "<strong style='color: red;'>Security check FAILED</strong><br>";
            echo "Would fall through to default redirect<br>";
        }
    } else {
        echo "✗ Redirect is falsy or null<br>";
        echo "Would fall through to default redirect<br>";
    }
    
} else {
    echo "<p>No POST data - showing test form</p>";
}

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<form method="post" style="border: 2px solid #28a745; padding: 20px; margin: 20px 0; background: #f8fff8;">
    <h3>🔬 Detailed Debug Form</h3>
    
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="redirect" value="/write">
    
    <p><strong>This form will debug the exact redirect execution</strong></p>
    <p>Redirect value: <code>/write</code></p>
    
    <label>Email:</label><br>
    <input type="email" name="email" value="test@example.com" style="width: 300px; padding: 8px; margin: 5px 0;"><br>
    
    <label>Password:</label><br>
    <input type="password" name="password" value="testpass" style="width: 300px; padding: 8px; margin: 5px 0;"><br><br>
    
    <button type="submit" style="padding: 12px 25px; background: #28a745; color: white; border: none; border-radius: 5px; font-size: 16px;">
        🔍 DEBUG REDIRECT EXECUTION
    </button>
</form>

<p><small>This won't actually log you in - it just tests the redirect parameter processing</small></p>