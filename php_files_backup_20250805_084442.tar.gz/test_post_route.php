<?php
echo "<h2>Testing Post Route</h2>";

// Test if we can access the post page directly
$test_url = "ledi-v-pogonah";
echo "<p>Testing with URL: $test_url</p>";

// Check if the post.php file exists
$post_file = $_SERVER['DOCUMENT_ROOT'] . '/pages/post/post.php';
if (file_exists($post_file)) {
    echo "✓ post.php file exists at: $post_file<br>";
} else {
    echo "<span style='color:red;'>✗ post.php file NOT FOUND at: $post_file</span><br>";
}

// Check .htaccess
$htaccess = $_SERVER['DOCUMENT_ROOT'] . '/.htaccess';
if (file_exists($htaccess)) {
    echo "✓ .htaccess file exists<br>";
    
    // Check if mod_rewrite rule exists
    $content = file_get_contents($htaccess);
    if (strpos($content, 'post/([^/]+)/?$') !== false) {
        echo "✓ Post rewrite rule found in .htaccess<br>";
    } else {
        echo "<span style='color:red;'>✗ Post rewrite rule NOT FOUND in .htaccess</span><br>";
    }
} else {
    echo "<span style='color:red;'>✗ .htaccess file NOT FOUND</span><br>";
}

// Test database query
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';
$query = "SELECT id_post, title_post FROM posts WHERE url_slug = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $test_url);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    echo "✓ Post found in database: ID={$row['id_post']}, Title={$row['title_post']}<br>";
} else {
    echo "<span style='color:red;'>✗ Post NOT FOUND in database</span><br>";
}

echo "<br><strong>Direct links to test:</strong><br>";
echo "<a href='/post/ledi-v-pogonah'>Test Post Link</a><br>";
echo "<a href='/pages/post/post.php?url_post=ledi-v-pogonah'>Direct PHP Link</a><br>";
?>