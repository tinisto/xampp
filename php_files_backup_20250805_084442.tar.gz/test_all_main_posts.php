<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';

echo "<h2>Testing All Main Page Post Links</h2>";
echo "<p>Click each link to test if it works or redirects to /error</p>";

// Replicate the exact queries from index_content_modern.php

echo "<h3>Section 1: 11-классники (Category 1)</h3>";
$query11 = "SELECT * FROM posts WHERE category = 1 ORDER BY date_post DESC LIMIT 6";
$result11 = mysqli_query($connection, $query11);

echo "<div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;'>";
while ($row11 = mysqli_fetch_assoc($result11)) {
    $imagePath = $_SERVER['DOCUMENT_ROOT'] . "/images/posts-images/{$row11['id_post']}_1.jpg";
    $imageUrl = file_exists($imagePath) 
        ? "/images/posts-images/{$row11['id_post']}_1.jpg" 
        : "/images/posts-images/default.png";
    
    echo "<div style='border: 1px solid #ccc; padding: 10px;'>";
    echo "<img src='{$imageUrl}' style='width: 100%; height: 150px; object-fit: cover;'>";
    echo "<h4>" . htmlspecialchars($row11['title_post']) . "</h4>";
    echo "<p>URL: " . htmlspecialchars($row11['url_post']) . "</p>";
    echo "<a href='/post/" . htmlspecialchars($row11['url_post']) . "' style='background: #28a745; color: white; padding: 5px 10px; text-decoration: none;'>Test Link</a>";
    echo "</div>";
}
echo "</div>";

echo "<hr>";

echo "<h3>Section 2: Абитуриенты (Category 2)</h3>";
$queryAbiturient = "SELECT * FROM posts WHERE category = 2 ORDER BY date_post DESC LIMIT 4";
$resultAbiturient = mysqli_query($connection, $queryAbiturient);

echo "<div style='display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;'>";
while ($rowAbiturient = mysqli_fetch_assoc($resultAbiturient)) {
    $imagePath = $_SERVER['DOCUMENT_ROOT'] . "/images/posts-images/{$rowAbiturient['id_post']}_1.jpg";
    $imageUrl = file_exists($imagePath) 
        ? "/images/posts-images/{$rowAbiturient['id_post']}_1.jpg" 
        : "/images/posts-images/default.png";
    
    echo "<div style='border: 1px solid #ccc; padding: 10px;'>";
    echo "<img src='{$imageUrl}' style='width: 100%; height: 150px; object-fit: cover;'>";
    echo "<h4>" . htmlspecialchars($rowAbiturient['title_post']) . "</h4>";
    echo "<p>URL: " . htmlspecialchars($rowAbiturient['url_post']) . "</p>";
    echo "<a href='/post/" . htmlspecialchars($rowAbiturient['url_post']) . "' style='background: #007bff; color: white; padding: 5px 10px; text-decoration: none;'>Test Link</a>";
    echo "</div>";
}
echo "</div>";

// Check for any special characters in URLs
echo "<hr>";
echo "<h3>URL Analysis:</h3>";
$allQuery = "SELECT url_post, title_post FROM posts WHERE category IN (1, 2) AND url_post LIKE '%[^a-z0-9-]%'";
$allResult = mysqli_query($connection, $allQuery);

if (mysqli_num_rows($allResult) > 0) {
    echo "<p style='color:red;'>Found posts with special characters in URLs:</p>";
    while ($row = mysqli_fetch_assoc($allResult)) {
        echo "- " . htmlspecialchars($row['url_post']) . " (" . htmlspecialchars($row['title_post']) . ")<br>";
    }
} else {
    echo "<p style='color:green;'>All URLs contain only valid characters (a-z, 0-9, hyphens)</p>";
}

mysqli_close($connection);
?>