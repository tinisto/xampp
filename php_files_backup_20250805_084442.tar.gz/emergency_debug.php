<?php
// Emergency debug to find the exact source of id_category error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set up environment
$_GET['news_type'] = 'vpo';
$_SERVER['REQUEST_URI'] = '/news/novosti-vuzov';

echo "<h1>Emergency Debug - Finding id_category</h1>";

// Function to capture all includes and requires
$included_files = [];
$original_include = null;
$original_require = null;
$original_include_once = null;
$original_require_once = null;

// Start output buffering to capture everything
ob_start();

// Set custom error handler to catch the exact error
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (strpos($errstr, 'id_category') !== false) {
        echo "<div style='background: red; color: white; padding: 10px;'>";
        echo "<h2>FOUND THE ERROR!</h2>";
        echo "<p>Error: $errstr</p>";
        echo "<p>File: $errfile</p>";
        echo "<p>Line: $errline</p>";
        echo "<h3>Backtrace:</h3>";
        debug_print_backtrace();
        echo "</div>";
    }
    return false;
});

// Override mysqli_query to log ALL queries
class mysqli_debug extends mysqli {
    public function query($query, $resultmode = MYSQLI_STORE_RESULT) {
        echo "<div style='background: #f0f0f0; padding: 5px; margin: 5px 0;'>";
        echo "<strong>Query:</strong> " . htmlspecialchars($query) . "<br>";
        
        if (strpos($query, 'id_category') !== false && strpos($query, 'id_category_news') === false) {
            echo "<div style='background: orange; padding: 5px;'>";
            echo "<strong>⚠️ FOUND id_category in query!</strong><br>";
            echo "Backtrace:<br>";
            $trace = debug_backtrace();
            foreach ($trace as $i => $call) {
                if (isset($call['file']) && isset($call['line'])) {
                    echo "#$i {$call['file']}:{$call['line']}<br>";
                }
            }
            echo "</div>";
        }
        echo "</div>";
        
        return parent::query($query, $resultmode);
    }
}

// Try to include the news page
try {
    // First, let's check what's in check_under_construction.php
    echo "<h2>Including check_under_construction.php</h2>";
    include_once $_SERVER['DOCUMENT_ROOT'] . '/common-components/check_under_construction.php';
    
    // Check if there's a global connection we need to replace
    if (isset($connection)) {
        echo "<p>Found global \$connection, replacing with debug version...</p>";
        $old_connection = $connection;
        $connection = new mysqli_debug($old_connection->host_info, 'root', 'root', '11klassniki_claude');
    }
    
    echo "<h2>Now loading news.php content...</h2>";
    
    // Load the news content
    $news_file = $_SERVER['DOCUMENT_ROOT'] . '/pages/common/news/news.php';
    $news_content = file_get_contents($news_file);
    
    // Check if there's any reference to id_category in the file
    if (strpos($news_content, 'id_category') !== false && strpos($news_content, 'id_category_news') === false) {
        echo "<div style='background: yellow; padding: 10px;'>";
        echo "<h3>Found 'id_category' in news.php!</h3>";
        preg_match_all('/.*id_category.*$/m', $news_content, $matches);
        foreach ($matches[0] as $match) {
            echo "<pre>" . htmlspecialchars($match) . "</pre>";
        }
        echo "</div>";
    }
    
    // Now actually include it
    include $news_file;
    
} catch (Exception $e) {
    echo "<div style='background: red; color: white; padding: 10px;'>";
    echo "<h2>Exception caught!</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    echo "</div>";
}

$output = ob_get_clean();

// Now let's also check all included files
echo "<h2>All included files:</h2>";
$all_includes = get_included_files();
foreach ($all_includes as $file) {
    // Check each file for id_category
    $content = @file_get_contents($file);
    if ($content && strpos($content, 'id_category') !== false && strpos($content, 'id_category_news') === false) {
        echo "<div style='background: #ffeeee; padding: 5px; margin: 2px;'>";
        echo "<strong>File contains 'id_category':</strong> $file<br>";
        
        // Find the specific lines
        $lines = explode("\n", $content);
        foreach ($lines as $num => $line) {
            if (strpos($line, 'id_category') !== false && strpos($line, 'id_category_news') === false) {
                echo "Line " . ($num + 1) . ": <code>" . htmlspecialchars(trim($line)) . "</code><br>";
            }
        }
        echo "</div>";
    }
}

echo "<h2>Output captured:</h2>";
echo "<div style='border: 1px solid #ccc; padding: 10px; max-height: 500px; overflow: auto;'>";
echo $output;
echo "</div>";
?>