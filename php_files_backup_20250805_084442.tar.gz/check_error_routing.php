<?php
echo "<h2>Checking Error Routing</h2>";

// Check if /error directory exists
$error_dir = $_SERVER['DOCUMENT_ROOT'] . '/error';
if (is_dir($error_dir)) {
    echo "<p>✓ /error directory exists</p>";
    
    // Check for index.php or error.php
    $files = ['index.php', 'error.php', '.htaccess'];
    foreach ($files as $file) {
        $path = $error_dir . '/' . $file;
        if (file_exists($path)) {
            echo "<p>Found: $file</p>";
            if ($file == 'index.php' || $file == 'error.php') {
                echo "<pre style='background: #f5f5f5; padding: 10px;'>";
                echo htmlspecialchars(substr(file_get_contents($path), 0, 500));
                echo "</pre>";
            }
        }
    }
} else {
    echo "<p>✗ No /error directory found</p>";
}

// Check .htaccess for error routing
echo "<h3>Checking .htaccess for error routes:</h3>";
$htaccess = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/.htaccess');
if (preg_match_all('/.*error.*$/mi', $htaccess, $matches)) {
    echo "<pre>";
    foreach ($matches[0] as $match) {
        echo htmlspecialchars(trim($match)) . "\n";
    }
    echo "</pre>";
}

// Check what file is actually being loaded
echo "<h3>Testing /error URL:</h3>";
echo "<p>When you visit /error, it might be loading a different file.</p>";
echo "<p>The simple error page is at: /pages/error/error.php</p>";

// List all PHP files that might handle errors
echo "<h3>Error-related files found:</h3>";
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($_SERVER['DOCUMENT_ROOT']));
foreach ($iterator as $file) {
    if ($file->isFile() && preg_match('/error.*\.php$/i', $file->getFilename())) {
        $path = str_replace($_SERVER['DOCUMENT_ROOT'], '', $file->getPathname());
        echo $path . "<br>";
    }
}
?>