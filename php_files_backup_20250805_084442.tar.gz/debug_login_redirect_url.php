<?php
echo "<h2>Debug Login Redirect URL Issue</h2>";

echo "<h3>Test URL encoding/decoding:</h3>";

$originalUrl = "/test_header_issue.php";
$encoded = urlencode($originalUrl);
$decoded = urldecode($encoded);

echo "Original: '$originalUrl'<br>";
echo "Encoded: '$encoded'<br>";
echo "Decoded: '$decoded'<br>";

echo "<h3>Check actual redirect parameter from URL:</h3>";
if (isset($_GET['redirect'])) {
    $redirect = $_GET['redirect'];
    echo "Redirect parameter: '$redirect'<br>";
    echo "Starts with /: " . (strpos($redirect, '/') === 0 ? 'yes' : 'no') . "<br>";
    echo "Starts with //: " . (strpos($redirect, '//') === 0 ? 'yes' : 'no') . "<br>";
    echo "Security check passes: " . ((strpos($redirect, '/') === 0 && strpos($redirect, '//') !== 0) ? 'yes' : 'no') . "<br>";
    
    // Test the exact logic from login_process_simple.php
    if ($redirect) {
        if (strpos($redirect, '/') === 0 && strpos($redirect, '//') !== 0) {
            echo "<strong style='color: green;'>✓ Would redirect to: '$redirect'</strong><br>";
        } else {
            echo "<strong style='color: red;'>✗ Security check failed</strong><br>";
        }
    }
} else {
    echo "No redirect parameter in URL<br>";
}

echo "<h3>Test login with correct redirect:</h3>";
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<form method="post" action="/pages/login/login_process_simple.php" style="border: 2px solid #dc3545; padding: 20px; margin: 20px 0; background: #fff5f5;">
    <h4>🔧 DEBUG LOGIN FORM</h4>
    
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="redirect" value="/test_header_issue.php">
    
    <p><strong>Redirect will be:</strong> /test_header_issue.php</p>
    
    <label>Email:</label><br>
    <input type="email" name="email" required style="width: 300px; padding: 8px; margin: 5px 0;"><br>
    
    <label>Password:</label><br>
    <input type="password" name="password" required style="width: 300px; padding: 8px; margin: 5px 0;"><br><br>
    
    <button type="submit" style="padding: 12px 25px; background: #dc3545; color: white; border: none; border-radius: 5px; font-size: 16px;">
        🐛 DEBUG LOGIN TEST
    </button>
</form>

<?php
echo "<h3>Alternative test - manual redirect check:</h3>";
echo "<p>Visit this URL manually:</p>";
echo "<a href='/login?redirect=" . urlencode("/test_header_issue.php") . "' target='_blank'>";
echo "/login?redirect=" . urlencode("/test_header_issue.php");
echo "</a>";
?>