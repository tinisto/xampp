<?php
session_start();

// Create a debug log
$debug_log = [];
$debug_log[] = "=== LOGIN PROCESS DEBUG ===";
$debug_log[] = "Time: " . date('Y-m-d H:i:s');

// Simple CSRF validation (skip for debug)
$debug_log[] = "CSRF check: skipped for debug";

// Get form data
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']) ? true : false;
$redirect = $_POST['redirect'] ?? null;

$debug_log[] = "Email: $email";
$debug_log[] = "Password: " . (empty($password) ? 'empty' : 'provided');
$debug_log[] = "Redirect: " . ($redirect ?? 'null');

if (!$email || empty($password)) {
    $debug_log[] = "ERROR: Missing email or password";
    echo implode("<br>", $debug_log);
    exit();
}

// Database connection
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/loadEnv.php';

if (!defined('DB_HOST') || !defined('DB_USER') || !defined('DB_PASS') || !defined('DB_NAME')) {
    $debug_log[] = "ERROR: Missing database config";
    echo implode("<br>", $debug_log);
    exit();
}

$connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($connection->connect_error) {
    $debug_log[] = "ERROR: Database connection failed";
    echo implode("<br>", $debug_log);
    exit();
}

$connection->set_charset("utf8mb4");

// Check user credentials
$stmt = $connection->prepare("SELECT id, password, email, role, occupation, is_active FROM users WHERE email = ?");
if (!$stmt) {
    $debug_log[] = "ERROR: SQL prepare failed";
    echo implode("<br>", $debug_log);
    exit();
}
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $debug_log[] = "ERROR: User not found";
    echo implode("<br>", $debug_log);
    exit();
}

$user = $result->fetch_assoc();
$debug_log[] = "User found: ID " . $user['id'];

// Verify password
if (!password_verify($password, $user['password'])) {
    $debug_log[] = "ERROR: Password verification failed";
    echo implode("<br>", $debug_log);
    exit();
}

// Check if account is active
if (isset($user['is_active']) && $user['is_active'] == 0) {
    $debug_log[] = "ERROR: Account not active";
    echo implode("<br>", $debug_log);
    exit();
}

$debug_log[] = "Login validation passed";

// Get username from email (part before @)
$username = explode('@', $email)[0];

// Set session variables
$_SESSION['user_id'] = $user['id'];
$_SESSION['email'] = $email;
$_SESSION['username'] = $username;
$_SESSION['role'] = $user['role'];
$_SESSION['occupation'] = $user['occupation'];
$_SESSION['logged_in'] = true;

$debug_log[] = "Session variables set";

// Handle "Remember Me"
if ($remember) {
    $cookieValue = $user['id'] . ':' . hash('sha256', $email . $user['password']);
    setcookie('remember_user', $cookieValue, time() + (30 * 24 * 60 * 60), '/', '', true, true);
    $debug_log[] = "Remember me cookie set";
}

// Close connection
$stmt->close();
$connection->close();

// REDIRECT LOGIC DEBUG
$debug_log[] = "=== REDIRECT LOGIC ===";
$debug_log[] = "Redirect parameter: " . ($redirect ?? 'null');

if ($redirect) {
    $debug_log[] = "Redirect is set";
    $debug_log[] = "Starts with /: " . (strpos($redirect, '/') === 0 ? 'yes' : 'no');
    $debug_log[] = "Starts with //: " . (strpos($redirect, '//') === 0 ? 'yes' : 'no');
    
    // Security check: only allow internal relative paths
    if (strpos($redirect, '/') === 0 && strpos($redirect, '//') !== 0) {
        $debug_log[] = "Security check PASSED - will redirect to: $redirect";
        $debug_log[] = "Header would be: Location: $redirect";
        
        // Show debug instead of redirecting
        echo implode("<br>", $debug_log);
        echo "<br><br><strong>WOULD REDIRECT TO: $redirect</strong>";
        echo "<br><a href='$redirect'>Click here to go to $redirect</a>";
        exit();
    } else {
        $debug_log[] = "Security check FAILED";
    }
} else {
    $debug_log[] = "No redirect parameter";
}

// Default redirect based on role
$debug_log[] = "Using default redirect";
if (isset($user['role']) && $user['role'] === 'admin') {
    $debug_log[] = "User is admin - would redirect to /dashboard";
    echo implode("<br>", $debug_log);
    echo "<br><br><strong>WOULD REDIRECT TO: /dashboard</strong>";
} else {
    $debug_log[] = "User is regular user - would redirect to /account";
    echo implode("<br>", $debug_log);
    echo "<br><br><strong>WOULD REDIRECT TO: /account</strong>";
}
?>