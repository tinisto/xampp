<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Debug Post Page</h2>";

// Simulate the post page request
$_GET['url_post'] = 'ledi-v-pogonah';

echo "<p>Simulating request to post.php with url_post = 'ledi-v-pogonah'</p>";

// Check what happens when we include the post file
echo "<h3>Including post.php:</h3>";
echo "<pre>";

// Capture any output
ob_start();
$error = null;

try {
    // Test if session can be started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
        echo "✓ Session started\n";
    }
    
    // Test database connection
    $db_file = $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';
    if (file_exists($db_file)) {
        require_once $db_file;
        echo "✓ Database connection file loaded\n";
        
        if (isset($connection)) {
            echo "✓ Database connection exists\n";
        } else {
            echo "✗ Database connection NOT established\n";
        }
    } else {
        echo "✗ Database connection file NOT FOUND\n";
    }
    
    // Now check what the post.php would do
    $url_post = 'ledi-v-pogonah';
    $query = "SELECT * FROM posts WHERE url_slug = ?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "s", $url_post);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        echo "✓ Post data retrieved successfully\n";
        echo "Title: " . $row['title_post'] . "\n";
        
        // Check what content file it's trying to load
        $mainContent = 'pages/post/post-content.php';
        $contentFile = $_SERVER['DOCUMENT_ROOT'] . '/' . $mainContent;
        
        if (file_exists($contentFile)) {
            echo "✓ Content file exists: $contentFile\n";
        } else {
            echo "✗ Content file NOT FOUND: $contentFile\n";
        }
        
        // Check for template
        $templateFile = $_SERVER['DOCUMENT_ROOT'] . '/common-components/template.php';
        if (file_exists($templateFile)) {
            echo "✓ Template file exists\n";
        } else {
            echo "✗ Template file NOT FOUND: $templateFile\n";
        }
    } else {
        echo "✗ Post NOT FOUND in database\n";
    }
    
} catch (Exception $e) {
    $error = $e->getMessage();
}

$output = ob_get_clean();
echo $output;

if ($error) {
    echo "\nERROR: $error\n";
}

echo "</pre>";

// Show the actual error by trying to access the URL
echo "<h3>Testing actual URL:</h3>";
echo "<iframe src='/post/ledi-v-pogonah' style='width: 100%; height: 200px; border: 1px solid #ccc;'></iframe>";
?>