<?php
// This file will test the /write URL directly
session_start();

echo "<h2>Test Write URL Direct Access</h2>";

echo "<h3>Current Request Info:</h3>";
echo "Request URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "Script Name: " . $_SERVER['SCRIPT_NAME'] . "<br>";
echo "Query String: " . ($_SERVER['QUERY_STRING'] ?? 'none') . "<br>";
echo "HTTP Host: " . $_SERVER['HTTP_HOST'] . "<br>";

echo "<h3>Test Different Write URLs:</h3>";
echo "<a href='/write' target='_blank'>Test /write</a><br>";
echo "<a href='/write/' target='_blank'>Test /write/</a><br>";
echo "<a href='/pages/write/write-simple.php' target='_blank'>Test direct file</a><br>";

echo "<h3>Check if user is logged in:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "✓ User is logged in (ID: " . $_SESSION['user_id'] . ")<br>";
} else {
    echo "✗ User is not logged in<br>";
}

echo "<h3>Create a simple write test:</h3>";
?>

<div style="border: 2px solid #007bff; padding: 20px; margin: 20px 0; background: #f8f9ff;">
    <h4>Simple Write Form Test</h4>
    <p>This tests if the write functionality works when accessed directly:</p>
    
    <?php if (!isset($_SESSION['user_id'])): ?>
        <div style="background: #d1ecf1; padding: 10px; border-radius: 5px; margin: 10px 0;">
            To send a message, please <a href="/login?redirect=/test_write_direct.php">login</a>.
        </div>
    <?php else: ?>
        <form method="post" style="background: white; padding: 15px; border-radius: 5px;">
            <label>Subject:</label><br>
            <input type="text" name="subject" style="width: 100%; padding: 8px; margin: 5px 0;"><br>
            
            <label>Message:</label><br>
            <textarea name="message" rows="4" style="width: 100%; padding: 8px; margin: 5px 0;"></textarea><br>
            
            <button type="submit" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px;">
                Send Test Message
            </button>
        </form>
        
        <?php if ($_POST): ?>
            <div style="background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; color: #155724;">
                ✓ Form data received! (This is just a test - no actual message sent)
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php
echo "<h3>Debug .htaccess processing:</h3>";
echo "The /write URL should be processed by this rule:<br>";
echo "<code>RewriteRule ^write/?$ pages/write/write-simple.php [QSA,NC,L]</code><br>";
echo "<br>If it's redirecting to /error, something is intercepting it before this rule.<br>";
?>