<?php
echo "<h2>Test Header Include Issue</h2>";

echo "<h3>Test 1: Check if header.php exists</h3>";
$headerFile = $_SERVER['DOCUMENT_ROOT'] . '/common-components/header.php';
if (file_exists($headerFile)) {
    echo "✓ header.php exists<br>";
    echo "Size: " . filesize($headerFile) . " bytes<br>";
    echo "Last modified: " . date('Y-m-d H:i:s', filemtime($headerFile)) . "<br>";
} else {
    echo "✗ header.php not found<br>";
}

echo "<h3>Test 2: Try to include header safely</h3>";
ob_start();
$headerError = null;

try {
    set_error_handler(function($severity, $message, $file, $line) use (&$headerError) {
        $headerError = "Error in header: $message at $file:$line";
        return true;
    });
    
    include $headerFile;
    
    restore_error_handler();
    echo "✓ Header included successfully<br>";
    
} catch (Exception $e) {
    $headerError = "Exception in header: " . $e->getMessage();
} catch (Error $e) {
    $headerError = "Fatal error in header: " . $e->getMessage();
}

$headerOutput = ob_get_clean();

if ($headerError) {
    echo "✗ " . htmlspecialchars($headerError) . "<br>";
} else {
    echo "✓ No errors from header<br>";
}

echo "<h3>Test 3: Create minimal write page without header</h3>";
?>

<div style="border: 2px solid #28a745; padding: 20px; margin: 20px 0; background: #f8fff8;">
    <h4>🧪 Minimal Write Page Test (No Header/Footer)</h4>
    <p>This tests the write functionality without the problematic includes:</p>
    
    <div style="background: #d1ecf1; padding: 15px; border-radius: 8px; margin: 15px 0;">
        <p>To send a message, please <a href="/login?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>">login</a>.</p>
    </div>
    
    <p><strong>✓ Login redirect test successful!</strong></p>
    <p>The login link includes the redirect parameter correctly.</p>
</div>

<?php
echo "<h3>Test 4: Check what's causing the redirect to /error</h3>";
echo "The issue is likely in the header.php file or one of its dependencies.<br>";
echo "Let's check if the header has any redirect logic:<br>";

if (file_exists($headerFile)) {
    $headerContent = file_get_contents($headerFile);
    if (strpos($headerContent, 'header(') !== false) {
        echo "⚠️ Header file contains header() redirects<br>";
    }
    if (strpos($headerContent, '/error') !== false) {
        echo "⚠️ Header file references /error<br>";
    }
    if (strpos($headerContent, 'exit') !== false || strpos($headerContent, 'die') !== false) {
        echo "⚠️ Header file contains exit/die statements<br>";
    }
}
?>