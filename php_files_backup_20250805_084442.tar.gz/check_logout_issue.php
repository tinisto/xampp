<?php
echo "<h2>Check Logout Issue</h2>";

echo "<h3>1. Check if logout.php exists</h3>";
$logoutFile = $_SERVER['DOCUMENT_ROOT'] . '/logout.php';
if (file_exists($logoutFile)) {
    echo "✓ logout.php exists<br>";
    echo "Size: " . filesize($logoutFile) . " bytes<br>";
    echo "Last modified: " . date('Y-m-d H:i:s', filemtime($logoutFile)) . "<br>";
} else {
    echo "✗ logout.php not found<br>";
}

echo "<h3>2. Check .htaccess logout rule</h3>";
$htaccess = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/.htaccess');
if (strpos($htaccess, 'logout') !== false) {
    echo "✓ Found logout in .htaccess<br>";
    
    // Extract logout rules
    $lines = explode("\n", $htaccess);
    foreach ($lines as $line) {
        if (stripos($line, 'logout') !== false && (stripos($line, 'RewriteRule') !== false || stripos($line, 'Redirect') !== false)) {
            echo "<code>" . htmlspecialchars(trim($line)) . "</code><br>";
        }
    }
} else {
    echo "✗ No logout rule found in .htaccess<br>";
}

echo "<h3>3. Test logout file safely</h3>";
if (file_exists($logoutFile)) {
    $content = file_get_contents($logoutFile);
    
    // Check for potential issues
    if (strpos($content, 'session_start()') !== false) {
        echo "✓ Contains session_start()<br>";
    } else {
        echo "⚠️ Missing session_start()<br>";
    }
    
    if (strpos($content, 'session_destroy()') !== false) {
        echo "✓ Contains session_destroy()<br>";
    } else {
        echo "⚠️ Missing session_destroy()<br>";
    }
    
    if (strpos($content, 'header(') !== false) {
        echo "✓ Contains redirect header<br>";
    } else {
        echo "⚠️ Missing redirect header<br>";
    }
    
    echo "<h4>File preview:</h4>";
    echo "<pre style='background: #f5f5f5; padding: 10px; max-height: 300px; overflow-y: auto;'>";
    echo htmlspecialchars(substr($content, 0, 1000));
    echo "</pre>";
}

echo "<h3>4. Simple logout test</h3>";
?>

<div style="border: 2px solid #dc3545; padding: 20px; margin: 20px 0; background: #fff5f5;">
    <h4>🚪 Simple Logout Function</h4>
    <p>This creates a safe logout without relying on the problematic file:</p>
    
    <a href="?logout=1" style="padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 5px;">
        Test Simple Logout
    </a>
</div>

<?php
// Handle simple logout
if (isset($_GET['logout'])) {
    session_start();
    
    // Clear all session variables
    $_SESSION = array();
    
    // Delete the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Clear remember me cookie
    setcookie('remember_user', '', time() - 3600, '/', '', true, true);
    
    // Destroy the session
    session_destroy();
    
    echo "<div style='background: #d4edda; padding: 15px; margin: 15px 0; border-radius: 5px; color: #155724;'>";
    echo "<h4>✅ Logout Successful!</h4>";
    echo "<p>Session destroyed and cookies cleared.</p>";
    echo "<p><a href='/'>Go to homepage</a></p>";
    echo "</div>";
}

echo "<h3>5. Current session status</h3>";
session_start();
if (isset($_SESSION['user_id'])) {
    echo "✓ Currently logged in as user ID: " . $_SESSION['user_id'] . "<br>";
} else {
    echo "✗ Not logged in<br>";
}
?>