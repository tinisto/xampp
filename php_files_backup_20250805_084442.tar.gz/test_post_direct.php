<?php
// Direct test bypassing all routing
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Direct Post Test</h2>";

// Manually set the post URL
$_GET['url_post'] = 'ledi-v-pogonah';

echo "<p>Testing with url_post = 'ledi-v-pogonah'</p>";

// Include the simple post page directly
$post_file = $_SERVER['DOCUMENT_ROOT'] . '/pages/post/post-simple.php';
if (file_exists($post_file)) {
    echo "<p>✓ Including post-simple.php...</p>";
    
    // Capture any errors
    try {
        ob_start();
        include $post_file;
        $output = ob_get_clean();
        
        if (strlen($output) > 0) {
            echo "<div style='border: 2px solid green; padding: 10px; margin: 10px 0;'>";
            echo "<h3>Post page output:</h3>";
            echo $output;
            echo "</div>";
        } else {
            echo "<p style='color: red;'>No output from post page</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color: red;'>✗ post-simple.php NOT FOUND</p>";
}
?>