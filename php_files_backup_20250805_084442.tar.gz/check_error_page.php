<?php
echo "<h2>Checking Error Page</h2>";

// Check if error page exists
$error_page = $_SERVER['DOCUMENT_ROOT'] . '/pages/error/error.php';
if (file_exists($error_page)) {
    echo "✓ error.php exists<br><br>";
    
    // Show first 50 lines of error.php
    echo "<h3>First 50 lines of error.php:</h3>";
    echo "<pre>";
    $lines = file($error_page, FILE_IGNORE_NEW_LINES);
    for ($i = 0; $i < min(50, count($lines)); $i++) {
        echo ($i + 1) . ": " . htmlspecialchars($lines[$i]) . "\n";
    }
    echo "</pre>";
} else {
    echo "✗ error.php NOT FOUND<br>";
}

// Check what URLs might redirect to /error
echo "<h3>Common reasons for /error redirect:</h3>";
echo "<ul>";
echo "<li>Missing required files</li>";
echo "<li>Database connection issues</li>";
echo "<li>Permission problems</li>";
echo "<li>Missing URL parameters</li>";
echo "</ul>";

// Test a direct post link
echo "<h3>Test Links:</h3>";
echo "<a href='/post/ledi-v-pogonah'>Test Post: Леди в погонах</a><br>";
echo "<a href='/pages/post/post.php?url_post=ledi-v-pogonah'>Direct Post Link</a><br>";
?>