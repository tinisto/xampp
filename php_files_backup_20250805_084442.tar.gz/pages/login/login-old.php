<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/common-components/check_under_construction.php';
$mainContent = 'login_content_safe.php';
$pageTitle = 'Вход - 11-классники';
include $_SERVER['DOCUMENT_ROOT'] . '/common-components/template-engine-authorization.php';