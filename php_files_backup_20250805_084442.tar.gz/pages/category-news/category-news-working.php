<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/common-components/check_under_construction.php';

// Get category information
if (isset($_GET['url_category_news'])) {
    $urlCategory = mysqli_real_escape_string($connection, $_GET['url_category_news']);
    
    // Fetch category data
    $queryCategoryNews = "SELECT * FROM news_categories WHERE url_category_news = ?";
    $stmt = mysqli_prepare($connection, $queryCategoryNews);
    mysqli_stmt_bind_param($stmt, 's', $urlCategory);
    mysqli_stmt_execute($stmt);
    $resultCategoryNews = mysqli_stmt_get_result($stmt);
    
    if ($resultCategoryNews && mysqli_num_rows($resultCategoryNews) > 0) {
        $categoryData = mysqli_fetch_assoc($resultCategoryNews);
        $pageTitle = $categoryData['title_category_news'];
        $pageDescription = "Новости категории: " . $categoryData['title_category_news'];
        $mainContent = 'pages/category-news/category-news-content-working.php';
        $additionalData = [
            'categoryData' => $categoryData,
            'urlCategory' => $urlCategory,
            'metaD' => $pageDescription,
            'metaK' => $categoryData['title_category_news'] . ', новости, образование'
        ];
        
        include $_SERVER['DOCUMENT_ROOT'] . '/common-components/template-engine-ultimate.php';
        
// Template configuration
$templateConfig = [
    'layoutType' => 'default',
    'cssFramework' => 'bootstrap',
    'headerType' => 'modern',
    'footerType' => 'modern',
    'darkMode' => true
];

renderTemplate($pageTitle, $mainContent, $templateConfig);
    } else {
        header("Location: /404");
        exit();
    }
} else {
    header("Location: /404");
    exit();
}