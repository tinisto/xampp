<?php
// Page configuration
$pageConfig = [
    'title' => 'Мои новости',
    'showBackButton' => true
];

// Specify content file
$pageContent = 'news-user-fields.php';

// Include the account template
include $_SERVER['DOCUMENT_ROOT'] . '/includes/account-template.php';