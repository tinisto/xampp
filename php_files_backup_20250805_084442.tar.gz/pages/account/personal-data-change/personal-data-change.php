<?php
// Page configuration
$pageConfig = [
    'title' => 'Изменить личные данные',
    'showBackButton' => true
];

// Specify content file
$pageContent = 'personal-data-change-fields.php';

// Include the account template
include $_SERVER['DOCUMENT_ROOT'] . '/includes/account-template.php';