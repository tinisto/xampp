<div class="text-center mt-4">
        <a href="/pages/logout/logout.php" class="btn btn-sm btn-outline-dark">
            <i class="fas fa-sign-out-alt"></i> Выход
        </a>
    </div>