<?php
// Page configuration
$pageConfig = [
    'title' => 'Удалить аккаунт',
    'showBackButton' => true
];

// Specify content file
$pageContent = 'delete-account-fields.php';

// Include the account template
include $_SERVER['DOCUMENT_ROOT'] . '/includes/account-template.php';