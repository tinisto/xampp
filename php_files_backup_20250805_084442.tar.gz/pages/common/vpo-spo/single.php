<?php
// Redirect to simplified version to avoid template engine issues
include $_SERVER['DOCUMENT_ROOT'] . '/pages/common/vpo-spo/single-simplified.php';
?>