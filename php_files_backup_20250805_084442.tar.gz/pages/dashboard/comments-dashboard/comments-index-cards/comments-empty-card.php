<div class="col d-flex">
    <div class="card rounded-lg shadow p-4 w-100 d-flex flex-column justify-content-center align-items-center bg-secondary">
        <h6 class="card-title text-xl font-weight-bold text-white">Empty Card</h6>
    </div>
</div>