<?php
// Redirect to simplified version for consistent design
include $_SERVER['DOCUMENT_ROOT'] . '/pages/school/school-single-simplified.php';
?>