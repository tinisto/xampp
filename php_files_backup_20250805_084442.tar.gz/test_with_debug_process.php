<?php
session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<h2>Test with Debug Login Process</h2>

<form method="post" action="/login_process_debug.php" style="border: 2px solid #dc3545; padding: 20px; margin: 20px 0; background: #fff5f5;">
    <h3>🛠️ DEBUG LOGIN FORM</h3>
    
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="redirect" value="/write">
    
    <p><strong>This will log every step to debug_login.txt</strong></p>
    <p>Redirect parameter: <code>/write</code></p>
    
    <label>Email:</label><br>
    <input type="email" name="email" required style="width: 300px; padding: 8px; margin: 5px 0;"><br>
    
    <label>Password:</label><br>
    <input type="password" name="password" required style="width: 300px; padding: 8px; margin: 5px 0;"><br><br>
    
    <button type="submit" style="padding: 12px 25px; background: #dc3545; color: white; border: none; border-radius: 5px; font-size: 16px;">
        🔍 LOGIN WITH DEBUG LOGGING
    </button>
</form>

<div style="background: #e2e3e5; padding: 15px; margin: 15px 0; border-radius: 5px;">
    <h4>After login, check:</h4>
    <ul>
        <li><a href="/debug_login.txt" target="_blank">Debug log file</a></li>
        <li>Where you were redirected</li>
    </ul>
</div>

<p><strong>Instructions:</strong></p>
<ol>
    <li>Use your real login credentials</li>
    <li>Submit the form</li>
    <li>Check where you're redirected</li>
    <li>Check the debug log to see exactly what happened</li>
</ol>