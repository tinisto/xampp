<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/database/db_connections.php';

echo "<h2>Checking All Posts</h2>";

// Get posts from main page query
$query = "SELECT id_post, title_post, url_post, category FROM posts WHERE category = 1 ORDER BY date_post DESC LIMIT 20";
$result = mysqli_query($connection, $query);

echo "<h3>Posts from Category 1 (Main Page):</h3>";
echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>ID</th><th>Title</th><th>URL Post</th><th>Test Link</th><th>Status</th></tr>";

$empty_urls = [];
$working_urls = [];

while ($row = mysqli_fetch_assoc($result)) {
    $url_post = $row['url_post'];
    $has_url = !empty($url_post);
    
    echo "<tr>";
    echo "<td>{$row['id_post']}</td>";
    echo "<td>" . htmlspecialchars($row['title_post']) . "</td>";
    echo "<td>" . ($has_url ? htmlspecialchars($url_post) : "<span style='color:red;'>EMPTY</span>") . "</td>";
    echo "<td>";
    
    if ($has_url) {
        echo "<a href='/post/{$url_post}' target='_blank'>Test</a>";
        $working_urls[] = $url_post;
    } else {
        echo "<span style='color:red;'>No URL</span>";
        $empty_urls[] = $row['id_post'];
    }
    
    echo "</td>";
    echo "<td>" . ($has_url ? "✓ Has URL" : "✗ Missing URL") . "</td>";
    echo "</tr>";
}

echo "</table>";

if (count($empty_urls) > 0) {
    echo "<h3 style='color:red;'>Posts with missing URLs (IDs): " . implode(", ", $empty_urls) . "</h3>";
    echo "<p>These posts will redirect to /error because they have no url_post value.</p>";
    
    // Try to fix by generating URLs from titles
    echo "<h3>Suggested fixes:</h3>";
    echo "<pre>";
    
    foreach ($empty_urls as $post_id) {
        $query = "SELECT title_post FROM posts WHERE id_post = $post_id";
        $result = mysqli_query($connection, $query);
        if ($row = mysqli_fetch_assoc($result)) {
            $title = $row['title_post'];
            // Generate URL from title
            $url = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title), '-'));
            $url = preg_replace('/-+/', '-', $url); // Remove multiple dashes
            
            echo "UPDATE posts SET url_slug = '$url' WHERE id_post = $post_id; -- {$title}\n";
        }
    }
    
    echo "</pre>";
}

// Also check for duplicate URLs
echo "<h3>Checking for duplicate URLs:</h3>";
$query = "SELECT url_post, COUNT(*) as count FROM posts WHERE url_post IS NOT NULL AND url_post != '' GROUP BY url_post HAVING count > 1";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) > 0) {
    echo "<p style='color:red;'>Found duplicate URLs:</p>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "URL '{$row['url_post']}' appears {$row['count']} times<br>";
    }
} else {
    echo "<p style='color:green;'>No duplicate URLs found.</p>";
}

mysqli_close($connection);
?>