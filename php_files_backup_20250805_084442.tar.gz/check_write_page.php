<?php
echo "<h2>Check Write Page Login Link</h2>";

$file = $_SERVER['DOCUMENT_ROOT'] . '/pages/write/write-simple.php';

echo "<h3>File Info:</h3>";
echo "Last modified: " . date('Y-m-d H:i:s', filemtime($file)) . "<br>";
echo "Size: " . filesize($file) . " bytes<br><br>";

echo "<h3>Search for login links:</h3>";
$content = file_get_contents($file);

// Look for login links
if (strpos($content, 'redirect=') !== false) {
    echo "✓ Contains redirect parameter<br>";
} else {
    echo "✗ Missing redirect parameter<br>";
}

// Extract the login link line
$lines = explode("\n", $content);
foreach ($lines as $i => $line) {
    if (strpos($line, 'войдите') !== false || strpos($line, 'login') !== false) {
        echo "<br><strong>Line " . ($i + 1) . ":</strong><br>";
        echo "<code>" . htmlspecialchars(trim($line)) . "</code><br>";
    }
}

echo "<h3>Test the actual write page login link:</h3>";
echo "Go to: <a href='/write' target='_blank'>https://11klassniki.ru/write</a><br>";
echo "Look at the login link and see if it includes the redirect parameter<br>";
?>